const express = require('express');
const cors = require('cors');
const mysql=require("mysql2");
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('frontend'));

const kapcsolat = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'könyvtár'
});

app.get("/konyvek",(req,res)=>
{
    kapcsolat.query("SELECT * FROM könyvek",(error,eredmenyek)=>
    {
        if(error)
        {
            res.status(404).json({ error: "Nincs találat" });
        }
        else
        {
            res.json(eredmenyek);
        }
    });
});

app.post("/konyvek",(req,res)=>
{
    const uj_konyv={
        cim:req.body.cim,
        iro:req.body.iro,
        ev:req.body.ev
    };
    kapcsolat.query("INSERT INTO könyvek(cím,szerző,év) VALUES(?,?,?)",[uj_konyv.cim,uj_konyv.iro,uj_konyv.ev],(error)=>
    {
        if(error)
        {
            res.status(404).json({ error: "Sikertelen feltöltés"});
        }
        else
        {
            res.status(201).json(uj_konyv);
        }
    });
});

app.delete("/konyvek/:id",(req,res)=>
{
    kapcsolat.query("DELETE FROM könyvek WHERE id=?",[req.params.id],(error)=>
    {
        if(error)
        {
            res.status(404).json({ error: 'Sikertelen törlés' });
        }
        else
        {
            res.status(204).send();
        }
    })
});

app.put("/konyvek/:id",(req,res)=>
{
    kapcsolat.query("UPDATE könyvek SET cím= ?, szerző= ?, év= ? WHERE id= ?",[req.body.cim,req.body.iro,req.body.ev,req.params.id],(error)=>
    {
        if(error)
        {
            res.status(404).json({error:"Sikertelen frissítés"});
        }
        else
        {
            res.status(204).send();
        }
    })
})

app.listen(PORT, () => {
    console.log(`Szerver fut: http://localhost:${PORT}`);
});