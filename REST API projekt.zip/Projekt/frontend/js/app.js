document.addEventListener("DOMContentLoaded",()=>
{
    let ev=new Date().getFullYear();
    document.getElementById("ev").max=ev;
    document.getElementById("ev_m").max=ev;
    if(document.getElementById("konyvek").childElementCount==0)
    {
        listazas();
    }
    vizsgalat();
    document.getElementById("feltoltes").addEventListener("submit",(event)=>
    {
        event.preventDefault();
        const cim=document.getElementById("cim");
        const iro=document.getElementById("iro");
        const ev=document.getElementById("ev");
        const uj_konyv={cim:cim.value,iro:iro.value,ev:ev.value};
        fetch("http://localhost:3000/konyvek",
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(uj_konyv)
        })
        .catch(error => console.error('Hiba:', error));

    });
    document.getElementById("modositas").addEventListener("submit",(event)=>
    {
        event.preventDefault();
        const cim=document.getElementById("cim_m");
        const iro=document.getElementById("iro_m");
        const ev=document.getElementById("ev_m");
        const id=document.getElementById("idik").value;
        const konyv={cim:cim.value,iro:iro.value,ev:ev.value};
        fetch(`http://localhost:3000/konyvek/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(konyv)
        })
        .then(()=>
        {
            listazas();
        })
        .catch(error => console.error('Hiba:', error));
    })
});

function vizsgalat()
{
    const konyvek=document.getElementById("konyvek");
    fetch("http://localhost:3000/konyvek")
    .then(response=>response.json())
    .then(adat=>
    {
        if(adat.length!=konyvek.childElementCount)
        {
            listazas();
        }
        setTimeout(vizsgalat,1);
    });
}

function listazas()
{
    const konyvek=document.getElementById("konyvek");
    const talalat=document.getElementById("nincs");
    const idik=document.getElementById("idik");
    konyvek.innerHTML="";
    fetch("http://localhost:3000/konyvek")
    .then(response=>response.json())
    .then(adat=>
    {
        if(adat.length>0)
        {
            idik.innerHTML="";
            document.getElementById("cim_m").disabled=false;
            document.getElementById("iro_m").disabled=false;
            document.getElementById("ev_m").disabled=false;
            document.getElementById("modosit").disabled=false;
            idik.addEventListener("change",()=>
            {
                let valasztot=adat.find(i=>i.id==idik.value);
                document.getElementById("cim_m").value=valasztot.cím;
                document.getElementById("iro_m").value=valasztot.szerző;
                document.getElementById("ev_m").value=valasztot.év;
            })
            talalat.classList.replace("d-block","d-none");
            document.getElementById("tablazat").classList.remove("d-none");
            let elso=adat[0];
            document.getElementById("cim_m").value=elso.cím;
            document.getElementById("iro_m").value=elso.szerző;
            document.getElementById("ev_m").value=elso.év;
            adat.forEach(konyv => 
            {
                const sor=document.createElement("tr");
                const id=document.createElement("td");
                const cim=document.createElement("td");
                const iro=document.createElement("td");
                const ev=document.createElement("td");
                const torles_oszlop=document.createElement("td");
                const torles=document.createElement("button");
                torles.classList.add("btn");
                torles.classList.add("btn-danger");
                torles.textContent="Törlés";
                torles.addEventListener("click",()=>
                {
                    fetch(`http://localhost:3000/konyvek/${konyv.id}`,
                    {
                        method:"DELETE"
                    })
                    .catch(error => console.error('Hiba:', error));
                });
                torles_oszlop.appendChild(torles);
                id.textContent=konyv.id;
                cim.textContent=konyv.cím;
                iro.textContent=konyv.szerző;
                ev.textContent=konyv.év;
                sor.appendChild(id);
                sor.appendChild(cim);
                sor.appendChild(iro);
                sor.appendChild(ev);
                sor.appendChild(torles_oszlop);
                konyvek.appendChild(sor);  
                const opcio=document.createElement("option");
                opcio.value=konyv.id;
                opcio.textContent=konyv.id;
                idik.appendChild(opcio);
            });
        }
        else
        {
            idik.innerHTML="";
            document.getElementById("cim_m").disabled=true;
            document.getElementById("iro_m").disabled=true;
            document.getElementById("ev_m").disabled=true;
            document.getElementById("modosit").disabled=true;
            document.getElementById("cim_m").value="";
            document.getElementById("iro_m").value="";
            document.getElementById("ev_m").value="";
            const opcio=document.createElement("option");
            opcio.textContent="Nincsenek könyvek";
            idik.appendChild(opcio);
            const nincs=document.createElement("h1");
            nincs.classList.add("text-center");
            nincs.textContent="Nincsenek könyvek";
            talalat.classList.replace("d-none","d-block");
            document.getElementById("tablazat").classList.add("d-none");
            if(talalat.childElementCount==0)
            {
                talalat.appendChild(nincs);
            }
        }
    })
    .catch(error => console.error('Hiba:', error));
}