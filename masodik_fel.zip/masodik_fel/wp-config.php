<?php
/**
 * A WordPress fő konfigurációs állománya
 *
 * Ebben a fájlban a következő beállításokat lehet megtenni: MySQL beállítások
 * tábla előtagok, titkos kulcsok, a WordPress nyelve, és ABSPATH.
 * További információ a fájl lehetséges opcióiról angolul itt található:
 * {@link http://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 *  A MySQL beállításokat a szolgáltatónktól kell kérni.
 *
 * Ebből a fájlból készül el a telepítési folyamat közben a wp-config.php
 * állomány. Nem kötelező a webes telepítés használata, elegendő átnevezni
 * "wp-config.php" névre, és kitölteni az értékeket.
 *
 * @package WordPress
 */

// ** MySQL beállítások - Ezeket a szolgálatótól lehet beszerezni ** //
/** Adatbázis neve */
define( 'DB_NAME', 'wordpress' );

/** MySQL felhasználónév */
define( 'DB_USER', 'root' );

/** MySQL jelszó. */
define( 'DB_PASSWORD', '' );

/** MySQL  kiszolgáló neve */
define( 'DB_HOST', 'localhost' );

/** Az adatbázis karakter kódolása */
define( 'DB_CHARSET', 'utf8mb4' );

/** Az adatbázis egybevetése */
define('DB_COLLATE', '');

/**#@+
 * Bejelentkezést tikosító kulcsok
 *
 * Változtassuk meg a lenti konstansok értékét egy-egy tetszóleges mondatra.
 * Generálhatunk is ilyen kulcsokat a {@link http://api.wordpress.org/secret-key/1.1/ WordPress.org titkos kulcs szolgáltatásával}
 * Ezeknek a kulcsoknak a módosításával bármikor kiléptethető az összes bejelentkezett felhasználó az oldalról.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY', '))ewP(M,g;>[PqU68,Kc6Tu^UW?|DzGPhY`qqoQC/$=)ykD/,A0K]Ve*gwfFz=i&' );
define( 'SECURE_AUTH_KEY', 'XjU:<#Oz^PW5A%@bY5](Y`oiiL g&+/3~]k5O<Y1Wb&(v^5L&j?p$RMZn-w5ralX' );
define( 'LOGGED_IN_KEY', ']^qjA)t9hd;m (~NlSuOL!rW,5y=B`=X_HHIiMps3+R_uws5IKo$BhAVCItBGatl' );
define( 'NONCE_KEY', 'DoB+5IFi#dMXkbx-`OUO(S`x2<I:q ZaoosGuDQ?f5:e-,GZ`#ABTeo3=Bt)0q )' );
define( 'AUTH_SALT',        'u-s1B]+-#Y[)Aqi^P$OevZu+.b+&E*q>,_? gm>4i+n/9,9sl:*U;/SN6=k]6=7d' );
define( 'SECURE_AUTH_SALT', 'U|.vj/h`&xIPauAYXfB]vCD67 3Be><b~xG/usSjO)vS B{9V=L<w06z2/i&B%Q^' );
define( 'LOGGED_IN_SALT',   'BYPbsPz};YixZggW_R9A;$+ovxaAyLZ}r|0Xmsy]K_AGw6#ZzKpY7*_xV9gTT=XA' );
define( 'NONCE_SALT',       'QEI)D@~BS?-{NwQ[SqM}INX(vj~]Dl?+KJWjKO`Ek-p6^8D:%tKg)P5n~QDJ!VEH' );

/**#@-*/

/**
 * WordPress-adatbázis tábla előtag.
 *
 * Több blogot is telepíthetünk egy adatbázisba, ha valamennyinek egyedi
 * előtagot adunk. Csak számokat, betűket és alulvonásokat adhatunk meg.
 */
$table_prefix = 'wp_';

/**
 * Fejlesztőknek: WordPress hibakereső mód.
 *
 * Engedélyezzük ezt a megjegyzések megjelenítéséhez a fejlesztés során.
 * Erősen ajánlott, hogy a bővítmény- és sablonfejlesztők használják a WP_DEBUG
 * konstansot.
 */
define('WP_DEBUG', false);

/* Ennyi volt, kellemes blogolást! */
/* That's all, stop editing! Happy publishing. */

/** A WordPress könyvtár abszolút elérési útja. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Betöltjük a WordPress változókat és szükséges fájlokat. */
require_once(ABSPATH . 'wp-settings.php');
