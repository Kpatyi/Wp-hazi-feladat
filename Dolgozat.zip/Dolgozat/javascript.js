function BMI(){
    let suly=document.getElementById("suly").value;
    let magassag=document.getElementById("magassag").value/100;
    let index=suly/(magassag*magassag);
    let tobblet=suly-25*magassag*magassag
    document.getElementById("index").value=index.toFixed(1);
    if(index<18)
    {
      document.getElementById("index").style.backgroundColor="rgba(255,255,0,0.4)";
      document.getElementById("tobblet").value=0;
    }
    else
    {
      if(index>=18 && index<=25)
      {
        document.getElementById("index").style.backgroundColor="#8F8";
        document.getElementById("tobblet").value=0;
      }
      else
      {
        if(index>25)
      {
        document.getElementById("index").style.backgroundColor="rgba(255,0,0,0.4)";
        document.getElementById("tobblet").value=tobblet.toFixed(0);
      }

      }
    }
  }
  function BMI2(){
    let suly=document.getElementById("suly2").value;
    let magassag=document.getElementById("magassag2").value;
    document.getElementById("suly_t").innerHTML=suly+" "+"kg";
    document.getElementById("magassag_t").innerHTML=magassag+" "+"cm";
    document.getElementById("suly_t").style.color="blue";   
    document.getElementById("magassag_t").style.color="blue";
    let magassag2=magassag/100;
    let index=suly/(magassag2*magassag2);
    document.getElementById("index2").value=index.toFixed(2);
    if(index<18)
    {
      document.getElementById("index2").style.backgroundColor="rgba(255,255,0,0.4)";
      testkep.innerHTML = '<img src="body_thin.gif">'
    }
    else
    {
      if(index>=18 && index<=25)
      {
        document.getElementById("index2").style.backgroundColor="#8F8";
        testkep.innerHTML = '<img src="body_correct.gif">'
      }
      else
      {
        if(index>25)
      {
        document.getElementById("index2").style.backgroundColor="rgba(255,0,0,0.4)";
        testkep.innerHTML = '<img src="body_fat.gif">'
      }

      }
    }
  }
